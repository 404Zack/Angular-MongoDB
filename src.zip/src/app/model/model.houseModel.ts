export class houseModel {
    id: number;
    name: string;
    series:String[];
}