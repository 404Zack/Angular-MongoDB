import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import exporting from 'highcharts/modules/exporting';
import offline from 'highcharts/modules/offline-exporting';
exporting(Highcharts);
offline(Highcharts);

import {
  Router,
  RouterLink
} from '@angular/router';
import { CommonService } from '../GetData.service';
import { Title } from '@angular/platform-browser';
import { houseModel } from '../model/model.houseModel';

@Component({
  selector: 'app-global-house-price',
  templateUrl: './global-house-price.component.html',
  styleUrls: ['./global-house-price.component.css']
})
export class GlobalHousePriceComponent implements OnInit {
  date: String[];
  i: number;
  j: number;
  EquallyWeighted: String[];
  loading = true;

  HouseModel: houseModel= new houseModel();
  HousePriceGroupe:Array<houseModel>;

  Highcharts = Highcharts;
  chartOptions={
    series: [{
      data: this.EquallyWeighted,
      type: 'line',
      name: 'GlobalHousePriceIndex'
    }],
    title: {
      text: 'Linear chart'
    },
    xAxis: {
      categories: this.date
    }
  };
  Highcharts1 = Highcharts;
  
  chartOptions1:any;
  
  constructor(private router: Router, private title: Title, private newService: CommonService) {}

  ngOnInit() {

    this.newService.GetGlobalHousePrice().subscribe(data => {
      this.EquallyWeighted = new Array();
      this.date = new Array();
      this.i = 0;
      //console.log(data[0]["country"]);
      data.forEach(element => {

        this.EquallyWeighted[this.i] = element["equally_weighted"];
        this.date[this.i] = element["dateq"];
        this.i = this.i + 1;

      });
      //console.log(this.EquallyWeighted);
      //console.log(this.date);
      this.Highcharts = Highcharts;
      this.chartOptions = {
        series: [{
          data: this.EquallyWeighted,
          type: 'line',
          name: 'GlobalHousePriceIndex'
        }],
        title: {
          text: 'Linear chart'
        },
        xAxis: {
          categories: this.date
        },
      };
      //this.updateData(this.countries, this.RealCreditGrowth);

    });


    this.newService.getHousePricesCountYear().subscribe(data => {
      this.HousePriceGroupe=new Array();
      this.i = 0;
      //console.log(data[0]["country"]);
      data.forEach(element => {
        this.HouseModel.name=element["location"];
        this.HouseModel.series=new Array();
        for (let i = 0; i < 19; i++){
          this.HouseModel.series[i]=element[2000+i];
        }
        
        this.HousePriceGroupe[this.i]=this.HouseModel;
        this.i = this.i + 1;
        this.HouseModel=null;
        this.HouseModel=new houseModel();

      });
      //console.log(this.HousePriceGroupe);
      //console.log(this.countries);
      //console.log(this.Dates);
      //console.log(this.Values);
      this.Highcharts1 = Highcharts;
      this.chartOptions1 = {
        
        series: [],
       
        title: {
          text: 'Linear chart with multiple series'
        },
        xAxis: {
          categories: ["2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018"]
        },
      };
    
      
     
      for (let i = 0; i < this.HousePriceGroupe.length; i++){
        this.chartOptions1.series[i]={
          data: this.HousePriceGroupe[i].series,
          type: 'line',
          name: this.HousePriceGroupe[i].name
        }
      }

      //this.updateData(this.countries, this.RealCreditGrowth);

    });


  }

}
