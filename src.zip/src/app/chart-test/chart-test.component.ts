import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chart-test',
  templateUrl: './chart-test.component.html',
  styleUrls: ['./chart-test.component.css']
})
export class ChartTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
